package com.turfx.service;

public interface EmailService 
{
	void sendOtpEmail(String toEmail, String otp);

}
